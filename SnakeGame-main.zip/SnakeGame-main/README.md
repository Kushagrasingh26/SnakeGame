# SnakeGame
## Goal
To make Snake to eat food and increase length of Snake 
and when Snake make collision with his body or border the game will over and  display Game over massege and Score.
### Control
Arrow keys are use to change direction of Snake
